// Exercicio 5, isso que será impresso na tela:
o ramo
mo
6