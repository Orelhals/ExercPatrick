#include <stdio.h>
#include <stdlib.h>

int main(void){
    int pulo[5] = {10,9,8,7,5};

    printf("%d",(*(pulo+2))); // Letra A
};