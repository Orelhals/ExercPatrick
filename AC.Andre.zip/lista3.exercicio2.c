int i = 3, j = 5;
int *p, *q;
p = &i;
q = &j;

/*
a) p == &i resulta em 1 (true)
b) *p - *q resulta em -2
c) **&p resulta em 3
d) 3* - *p/(*q)+7 resulta em 6
*/